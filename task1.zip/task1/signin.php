<?php
include("connection.php");
?>
<html>
<head><title>hello</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
	<style>
			div {
				    border-radius: 10px;
				    background-color: #eaecef;
				    padding: 10px;
				}
	    .topnav {
	                 color: #66d2e2;
	                 text-align: center;
	                 padding: 14px 16px;
	                 text-decoration: none;
	                 font-size: 15px;
	                 margin:50px;
	             }
	   .padding-0{
                     padding-right:0;
                     padding-left:0;
                 }

    </style>
	</head>
	<body>
		<form action="" method="POST" id="demo">
			<div class="topnav" >
				<div class="row">
					<div class="col-md-1 col-md-offset-4 col-sm-3 padding-0">UserName:</div>
					<div class="col-md-1 col-sm-9 padding-0" >
						<input type="text" name="username" value="" id="username">
					</div>
		        </div>
                <div class="row">
			        <div class="col-md-1 col-md-offset-4 col-sm-3 padding-0">password:</div>
			        <div class="col-md-1 col-sm-9 padding-0" >
				        <input type="password" name="password" value="" placeholder="password">
				    </div>
		        </div>
                <div class="row">
				<div class="col-md-1 col-md-offset-4 col-sm-3 padding-0"><a href="signup.php">create account</a></div>
				<div class="col-md-2 col-sm-9 padding-0" >
				<input name="submit" type="submit" value="login">
			</div>
		</div>
	        </div>
		</form>	
<?php
		       if(isset($_POST['submit']))
		       {    
		           	$username=$_POST['username'];

		       		$password=$_POST['password'];

		       		if($username!=""&&$password!="")
		       		{	
		       			$sql = "SELECT * FROM user WHERE name='$username'
		       					UNION
		       					SELECT * FROM user WHERE password='$password'";

                        $result = mysqli_query($con,$sql);

                        $count=mysqli_num_rows($result);

                        if($count>0)
                        {
                        	 header('location: display.php');
                        }
                        else
                        {
                        	echo"there is no user with that username or password";
                        }
                      

		       		}
		       		else
		       		{
		       			echo "there must be an empty data field";
		       		}
		       }
		       ?>
</body>
</html>

