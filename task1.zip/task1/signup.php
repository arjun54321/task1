<?php
include("connection.php");
?>
<!doctype html>
<html>
<head>
	<title>hello</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
	<style>
			div {
				    border-radius: 10px;
				    background-color: #eaecef;
				    padding: 10px;
				}
	    .topnav {
	                 color: #66d2e2;
	                 text-align: center;
	                 padding: 14px 16px;
	                 text-decoration: none;
	                 font-size: 15px;
	                 margin:50px;
	             }
	   .padding-0{
                     padding-right:0;
                     padding-left:0;
                 }

    </style>
</head>
<body>
	<form method="POST">
		<div class="topnav" >
			<div class="row">
				<div class="col-md-1 col-md-offset-4 col-sm-3 padding-0" >UserName:</div>
				<div class="col-md-1 col-sm-9 padding-0" ><input type="text" name="name" id="name" size="20"></div>
			</div>
			<div class="row">
				<div class="col-md-1 col-md-offset-4 col-sm-3 padding-0">Password:</div>
				<div class="col-md-1 col-sm-9 padding-0" ><input type="password" name="pass1" id="pass" size="20"></div>
			</div>
			<div class="row">
				<div class="col-md-1 col-md-offset-4 col-sm-3 padding-0">Password1:</div>
				<div class="col-md-1 col-sm-9 padding-0" ><input type="password" name="pass2" id="pass" size="20"></div>
			</div>
			<div class="row">
				<div class="col-md-1 col-md-offset-4 col-sm-3 padding-0">Country:</div>
				<div class="col-md-1 col-sm-9 padding-0" >
					<select name="country">
						<option  id="india" value="india" >india</option>
						<option  id="china" value="china" >china</option>
						<option  id="korea" value="korea" >korea</option>
				    </select>
				</div>
			</div>
			<div class="row">
				<div class="col-md-1 col-md-offset-4 col-sm-3 padding-0">Select Courses:</div>
				<div class="col-md-2 col-sm-9 padding-0" >
					<input type="checkbox" name="check" value="website_designing">website_designing<br>
					<input type="checkbox" name="check" value="web_development">web_development
			    </div>
		    </div>
			<div class="row">
				<div class="col-md-1 col-md-offset-4 col-sm-3 padding-0"><a href="signin.php">sign in instead</a></div>
				<div class="col-md-2 col-sm-9 padding-0" >
				<input name="submit" type="submit">
			</div>
		</div>
	</div>
	</form>
<?php
		       if($_POST['submit'])
		       {    
		           	$name=$_POST['name'];

		       		$pa1=$_POST['pass1'];

		       		$pa2=$_POST['pass2'];

		       		$country=$_POST['country'];

		       		$course=$_POST['check'];

		       		//echo $name;
		       		
		       		if($pa1!=$pa2)
		       		{
		       			echo("password does not match");
		       		}
		       		else

		       		if($name!=""&&$country!=""&&$course!=""&&$pa1!=""&&$pa2!="")
		       		{	
		       		 $query="INSERT INTO USER(name,password,checkbox,dropdown) VALUES('$name','$pa1','$country','$course')";
		       		 //echo $query;
		       	     $data=mysqli_query($con,$query);
		       			if($data)
		       			{
		       				header('location: signup.php');
		       			}
		       			else
		       			{
		       				echo"not inserted";
		       			}

		       		}
		       		else
		       		{
		       			echo "there must be an empty data field";
		       		}
		       }
		       ?>
</body>	
</html>
